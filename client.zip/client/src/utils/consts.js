export const ADMIN_ROUTE = '/admin'
export const TEACHER_ROUTE = '/teacher'
export const STUDENT_ROUTE = '/student'
export const LOGIN_ROUTE = '/login'