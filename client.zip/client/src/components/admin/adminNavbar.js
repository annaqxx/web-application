import React from 'react';
import { Navbar, Nav, Container } from 'react-bootstrap';
import { ADMIN_ROUTE } from '../../utils/consts';
import { useNavigate } from 'react-router-dom';
import { observer } from 'mobx-react-lite';
import { Context } from '../../index';
import { logout } from '../../http/userAPI';

const AdminNavbar = observer(() => {
  const navigate = useNavigate();
  const { user } = React.useContext(Context);

  const handleLogout = async () => {
    try {
      await logout();
      user.setUser({});
      user.setIsAuth(false);
      navigate(ADMIN_ROUTE);
    } catch (error) {
      console.error('Ошибка при выходе:', error);
    }
  };

  return (
    <Navbar bg="dark" variant="dark" expand="lg">
      <Container>
        <Navbar.Brand href={ADMIN_ROUTE}>Админ-панель</Navbar.Brand>
        <Navbar.Toggle aria-controls="basic-navbar-nav" />
        <Navbar.Collapse id="basic-navbar-nav">
          <Nav className="me-auto">
            <Nav.Link href={ADMIN_ROUTE}>Пользователи</Nav.Link>
            {/* Добавьте другие ссылки по мере необходимости */}
          </Nav>
          <Nav>
            <Nav.Link onClick={handleLogout}>Выйти</Nav.Link>
          </Nav>
        </Navbar.Collapse>
      </Container>
    </Navbar>
  );
});

export default AdminNavbar;