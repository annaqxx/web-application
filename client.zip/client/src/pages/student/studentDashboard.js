import React from 'react';

const StudentPage = () => {
  return (
    <div>
      <h1>Панель студента</h1>
      <p>Эта страница в разработке.</p>
    </div>
  );
};

export default StudentPage;