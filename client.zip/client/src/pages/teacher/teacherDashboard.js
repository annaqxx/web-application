import React from 'react';

const TeacherPage = () => {
  return (
    <div>
      <h1>Панель преподавателя</h1>
      <p>Эта страница в разработке.</p>
    </div>
  );
};

export default TeacherPage;