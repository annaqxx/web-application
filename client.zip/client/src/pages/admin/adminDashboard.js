import React  from 'react';
import { Container } from 'react-bootstrap';
import UserManagement from '../../components/admin/userManagment';
import AdminNavbar from '../../components/admin/adminNavbar';

const AdminPage = () => {
  return (
    <>
      <AdminNavbar />
      <Container className="mt-4">
        <UserManagement />
      </Container>
    </>
  );
}

export default AdminPage;